# FusionAI Backend Setup Guide

## Quick Deploy (5 minutes)

### Step 1: Deploy to Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Open terminal in this `fusionai-backend` folder
3. Run: `vercel`
4. Follow prompts (link to your Vercel account, accept defaults)
5. Your backend is now live at something like `fusionai-backend.vercel.app`

### Step 2: Add Your API Keys as Environment Variables

Go to https://vercel.com → Your project → Settings → Environment Variables

Add these 4 variables:

| Name | Value | Where to get it |
|------|-------|-----------------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` | console.anthropic.com |
| `OPENAI_API_KEY` | `sk-...` | platform.openai.com |
| `GEMINI_API_KEY` | `AIza...` | aistudio.google.com |
| `GROK_API_KEY` | `xai-...` | console.x.ai |

After adding, click "Redeploy" to pick up the new vars.

### Step 3: Update the Frontend

In your `index.html` (the FusionAI frontend), find this line near the top of the script:

```
const API_URL = 'https://YOUR-BACKEND.vercel.app/api/chat';
```

Replace `YOUR-BACKEND` with your actual Vercel URL.

### Step 4: Add Stripe (when ready for real payments)

1. Create a Stripe account at stripe.com
2. Add your Stripe publishable key to the frontend
3. Create Products/Prices in Stripe Dashboard:
   - Starter: $15/month
   - Pro: $49/month  
   - Enterprise: $199/month
4. Use Stripe Checkout for payment flow
5. Store subscription status in Firestore

## Cost Monitoring

Set up billing alerts on each API provider:
- Anthropic: console.anthropic.com → Usage
- OpenAI: platform.openai.com → Usage
- Google AI: aistudio.google.com → API keys → Quotas
- xAI: console.x.ai → Usage

Set monthly budget caps:
- Start with $50/month total across all providers
- Increase as you get paying users
- The free tier costs ~$0.003/prompt = ~$0.45/month per active free user

## Architecture

```
User Browser (index.html on Netlify)
    ↓ POST /api/chat
Vercel Serverless Function (api/chat.js)
    ↓ Parallel requests with YOUR keys
    ├→ Anthropic API (Claude)
    ├→ OpenAI API (ChatGPT)  
    ├→ Google API (Gemini)
    └→ xAI API (Grok)
    ↓ Synthesize responses
    ↓ Return combined answer
User sees synthesized response
```

Users never see or need API keys. They just sign up and chat.
